#!/usr/bin/env bash

docker network create hive
docker container list --all | grep hive-mongo > /dev/null \
        && docker container stop hive-mongo > /dev/null \
        && docker container rm -f hive-mongo > /dev/null
echo -n "Hive-Mongo Container: "
docker run -d --name hive-mongo                     \
    --network hive-service                          \
    -v ${PWD}/.mongodb-data:/data/db                \
    -p 27020:27017                                  \
    mongo:4.4.0 | cut -c -9
echo "Running directly on the machine..."
ps -ef | grep gunicorn | awk '{print $2}' | xargs kill -9
echo "setup_venv"
#virtualenv -p `which python3.6` .venv
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
LD_LIBRARY_PATH="$PWD/hive/util/did/" python manage.py runserver
